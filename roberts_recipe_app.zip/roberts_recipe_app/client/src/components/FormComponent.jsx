import React, { useState, useEffect } from "react";
import axios from "axios";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";

function FormComponent({ selectedRecord, onFormSubmit, error, setError }) {
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    description: "",
  });
  const [editMode, setEditMode] = useState(false);
  const [isNew, setIsNew] = useState(false);
  const [color, changeColor] = useState("white");
  const [isDeleted, setIsDeleted] = useState(false);

  useEffect(() => {
    if (selectedRecord) {
      setFormData({
        title: selectedRecord.title || "",
        author: selectedRecord.author || "",
        description: selectedRecord.description || "",
      });
      setEditMode(false);
      setIsNew(false);
      changeColor("white");
      setIsDeleted(false);
    }
  }, [selectedRecord]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNew = () => {
    setFormData({ title: "", author: "", description: "" });
    setEditMode(true);
    setIsNew(true);
    setIsDeleted(true);
    setError({});
    changeColor("rgb(146, 218, 241)");
  };

  const handleEdit = () => {
    setEditMode(true);
    setError({});
    changeColor("rgb(146, 218, 241)");
  };

  const handleDelete = async () => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_API_URL}/records/${selectedRecord.id}/`
      );
      setFormData({ title: "", author: "", description: "" });
      setIsDeleted(true);
      setError({});
      alert("Delete was successful");
      onFormSubmit();
    } catch (error) {
      setError(error.response.data.errors);
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.title) newErrors.title = { message: "Title is required" };
    if (!formData.author) newErrors.author = { message: "Author is required" };
    if (!formData.description) newErrors.description = { message: "Description is required" };
    return newErrors;
  };

  const handleSave = async () => {
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setError(validationErrors);
      return;
    }

    try {
      setError({});
      if (isNew) {
        await axios.post(`${process.env.REACT_APP_API_URL}/records/`, formData);
      } else {
        await axios.put(
          `${process.env.REACT_APP_API_URL}/records/${selectedRecord.id}/`,
          formData
        );
      }
      setFormData({ title: "", author: "", description: "" });
      setEditMode(false);
      setIsNew(false);
      setIsDeleted(true); // Reset delete state after save
      alert("Save was successful");
      onFormSubmit();
      changeColor("white");
    } catch (error) {
      console.error("Error saving record:", error.response.data);
      setError(error.response.data.errors || {});
    }
  };

  return (
    <div className="Form">
      <div className="form-buttons">
        <Button
          variant="primary"
          onClick={handleNew}
        >
          New
        </Button>
        <Button
          variant="info"
          className="editBtn"
          onClick={handleEdit}
          disabled={!selectedRecord?.id || isDeleted}
        >
          Edit
        </Button>
        <Button
          variant="danger"
          onClick={handleDelete}
          disabled={!selectedRecord?.id || isDeleted}
        >
          Delete
        </Button>
        <Button
          variant="success"
          size="lg"
          onClick={handleSave}
          disabled={!editMode}
        >
          Save
        </Button>
      </div>
      <div className="form-fields">
        <label>
          <InputGroup className="inputGroup" size="lg">
            <InputGroup.Text id="inputGroup-sizing-lg">Recipe Title:</InputGroup.Text>
            <Form.Control
              name="title"
              style={{ backgroundColor: `${color}` }}
              type="text"
              aria-label="Title"
              aria-describedby="inputGroup-sizing-sm"
              value={formData.title}
              onChange={handleChange}
              disabled={!editMode}
            />
          </InputGroup>
          <p className="error-message">{error.title?.message}</p>
        </label>
        <label>
          <InputGroup size="lg">
            <InputGroup.Text id="inputGroup-sizing-lg">Author:</InputGroup.Text>
            <Form.Control
              name="author"
              style={{ backgroundColor: `${color}` }}
              aria-label="Author"
              aria-describedby="inputGroup-sizing-sm"
              value={formData.author}
              onChange={handleChange}
              disabled={!editMode}
            />
          </InputGroup>
          <p className="error-message">{error.author?.message}</p>
        </label>
        <label>
          <InputGroup>
            <InputGroup.Text>Recipe<br />Description:</InputGroup.Text>
            <Form.Control
              name="description"
              style={{ backgroundColor: `${color}` }}
              as="textarea"
              aria-label="Description"
              value={formData.description}
              onChange={handleChange}
              disabled={!editMode}
              rows="8"
            />
          </InputGroup>
          <p className="error-message">{error.description?.message}</p>
        </label>
      </div>
    </div>
  );
}

export default FormComponent;
