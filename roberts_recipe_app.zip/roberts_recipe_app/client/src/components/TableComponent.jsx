import React, { useEffect, useState } from "react";
import axios from "axios";
import Table from "react-bootstrap/Table";

function TableComponent({ onSelectRecord, refreshTable }) {
  const [records, setRecords] = useState([]);
  const [userVotes, setUserVotes] = useState(() => {
    const savedVotes = localStorage.getItem("userVotes");
    return savedVotes ? JSON.parse(savedVotes) : {};
  });

  useEffect(() => {
    fetchRecords();
  }, [refreshTable]);

  useEffect(() => {
    localStorage.setItem("userVotes", JSON.stringify(userVotes));
  }, [userVotes]);

  const fetchRecords = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/records/`
      );
      setRecords(response.data);
    } catch (err) {
      console.error("Error fetching records:", err.response ? err.response.data : err);
    }
  };

  const handleTitleClick = async (id) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/records/${id}/`
      );
      onSelectRecord(response.data);
    } catch (err) {
      console.error("Error fetching record:", err.response ? err.response.data : err);
    }
  };

  const handleVote = async (id, change) => {
    try {
      const record = records.find((record) => record.id === id);
      const currentVote = userVotes[id] || 0;

      let voteChange = change;
      if (currentVote === change) {
        voteChange = -change;
      } else if (currentVote !== 0) {
        voteChange = change * 2;
      }

      const updatedVotes = record.votes + voteChange;

      await axios.put(`${process.env.REACT_APP_API_URL}/records/${id}/`, {
        ...record,
        votes: updatedVotes,
      });

      setUserVotes((prevVotes) => ({
        ...prevVotes,
        [id]: currentVote === change ? 0 : change,
      }));

      fetchRecords();
    } catch (err) {
      console.error("Error updating votes:", err.response ? err.response.data : err);
    }
  };

  return (
    <div className="table-container">
      <Table striped variant="success" className="Table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Recipe Title</th>
            <th>Author</th>
            <th>Votes</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record, index) => (
            <tr
              key={record.id}
              className={
                userVotes[record.id] === 1
                  ? "upvoted"
                  : userVotes[record.id] === -1
                    ? "downvoted"
                    : ""
              }
            >
              <td>{index + 1}</td>
              <td onClick={() => handleTitleClick(record.id)}>{record.title}</td>
              <td>{record.author}</td>
              <td>
                <button
                  className={`upvote ${userVotes[record.id] === 1 ? "voted" : ""}`}
                  onClick={() => handleVote(record.id, 1)}
                  disabled={userVotes[record.id] === 1}
                >
                  ▲
                </button>
                <button
                  className={`downvote ${userVotes[record.id] === -1 ? "voted" : ""}`}
                  onClick={() => handleVote(record.id, -1)}
                  disabled={userVotes[record.id] === -1}
                >
                  ▼
                </button>
                {record.votes}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default TableComponent;
