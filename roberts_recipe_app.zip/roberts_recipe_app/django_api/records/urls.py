from django.urls import path
from .views import RecordListCreate, RecordRetrieveUpdateDestroy

urlpatterns = [
    path('records/', RecordListCreate.as_view(), name='record-list-create'),
    path('records/<int:id>/', RecordRetrieveUpdateDestroy.as_view(), name='record-detail'),
]
