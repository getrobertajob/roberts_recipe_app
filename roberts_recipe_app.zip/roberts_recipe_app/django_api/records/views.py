from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Record
from .serializers import RecordSerializer

class RecordListCreate(generics.ListCreateAPIView):
    serializer_class = RecordSerializer

    def get_queryset(self):
        return Record.objects.all().order_by('-votes')

class RecordRetrieveUpdateDestroy(generics.RetrieveUpdateDestroyAPIView):
    queryset = Record.objects.all()
    serializer_class = RecordSerializer
    lookup_field = 'id'

@api_view(['PUT'])
def update_record(request, id):
    try:
        record = Record.objects.get(id=id)
    except Record.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    data = request.data
    record.votes = data.get('votes', record.votes)
    
    serializer = RecordSerializer(record, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
