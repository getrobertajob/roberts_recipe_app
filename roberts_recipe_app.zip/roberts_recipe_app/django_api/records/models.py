from djongo import models

class Record(models.Model):
    title = models.CharField(max_length=40)
    author = models.CharField(max_length=40)
    votes = models.IntegerField(default=0)
    description = models.CharField(max_length=140)

    def __str__(self):
        return self.title
